import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { auth } from "../firebase";
import "../styles/Navbar.css";

const Navbar = ({ user }) => {
  const navigate = useNavigate();

  const handleLogout = async () => {
    await auth.signOut();
    navigate("/login");
  };

  return (
    <nav className="navbar">
      <h3>💸 Budget Planner</h3>
      <div className="nav-links">
        <Link to="/">Home</Link>
        {!user && <Link to="/login">Login</Link>}
        {user && (
          <>
            <Link to="/dashboard">Dashboard</Link>
            <Link to="/salary">Salary</Link>
            <Link to="/savings">Savings</Link> {/* ✅ New Link */}
          </>
        )}
        <Link to="/about">About</Link>
        {user && (
          <button onClick={handleLogout} className="logout-btn">
            Logout
          </button>
        )}
      </div>
    </nav>
  );
};

export default Navbar;

