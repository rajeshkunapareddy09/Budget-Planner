// src/components/SavingsGoalCard.js
import React, { useState } from "react";
import { doc, updateDoc } from "firebase/firestore";
import { db } from "../firebase";

const SavingsGoalCard = ({ goal, userId }) => {
  const [amount, setAmount] = useState("");

  const handleAddSavings = async () => {
    const newSaved = goal.saved + parseFloat(amount);
    await updateDoc(doc(db, "users", userId, "savings", goal.type), {
      saved: newSaved,
    });
    setAmount("");
  };

  const progress = Math.min((goal.saved / goal.target) * 100, 100);

  return (
    <div className="goal-card">
      <h3>{goal.type} Goal</h3>
      <p>Target: ₹{goal.target}</p>
      <p>Saved: ₹{goal.saved}</p>
      <p>Remaining: ₹{goal.target - goal.saved}</p>
      <div className="progress-bar">
        <div className="progress" style={{ width: `${progress}%` }} />
      </div>

      {goal.saved < goal.target ? (
        <div className="add-monthly">
          <input
            type="number"
            placeholder="Add this month"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
          />
          <button onClick={handleAddSavings}>Add</button>
        </div>
      ) : (
        <p className="completed">🎉 Goal Reached!</p>
      )}
    </div>
  );
};

export default SavingsGoalCard;

