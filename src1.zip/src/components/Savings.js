// src/components/SavingsDashboard.js
import React, { useState, useEffect } from "react";
import { db, auth } from "../firebase";
import { collection, doc, setDoc, onSnapshot, updateDoc } from "firebase/firestore";
import { useAuthState } from "react-firebase-hooks/auth";
import SavingsGoalCard from "./SavingsGoalCard";
import "../styles/Savings.css";

const SavingsDashboard = () => {
  const [user] = useAuthState(auth);
  const [goals, setGoals] = useState({});
  const [newType, setNewType] = useState("");
  const [newTarget, setNewTarget] = useState("");

  useEffect(() => {
    if (!user) return;

    const unsubscribe = onSnapshot(collection(db, "users", user.uid, "savings"), (snapshot) => {
      const goalData = {};
      snapshot.forEach((doc) => {
        goalData[doc.id] = doc.data();
      });
      setGoals(goalData);
    });

    return () => unsubscribe();
  }, [user]);

  const handleAddGoal = async () => {
    if (!newType || !newTarget) return;
    if (goals[newType]) {
      alert("Goal already exists for this type.");
      return;
    }

    await setDoc(doc(db, "users", user.uid, "savings", newType), {
      type: newType,
      target: parseFloat(newTarget),
      saved: 0,
    });

    setNewType("");
    setNewTarget("");
  };

  return (
    <div className="savings-dashboard">
      <h2>Savings Goals</h2>

      {/* Add New Goal Form */}
      <div className="new-goal-form">
        <input
          type="text"
          placeholder="Type (e.g., Health, Vacation)"
          value={newType}
          onChange={(e) => setNewType(e.target.value)}
        />
        <input
          type="number"
          placeholder="Target Amount"
          value={newTarget}
          onChange={(e) => setNewTarget(e.target.value)}
        />
        <button onClick={handleAddGoal}>Add Goal</button>
      </div>

      {/* Existing Goals */}
      <div className="goal-list">
        {Object.entries(goals).map(([key, goal]) => (
          <SavingsGoalCard key={key} goal={goal} userId={user.uid} />
        ))}
      </div>
    </div>
  );
};

export default SavingsDashboard;

