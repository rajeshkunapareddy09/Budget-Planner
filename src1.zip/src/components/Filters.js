// src/components/Filters.js
import React from "react";
import "./Filters.css";

const Filters = ({ month, setMonth, category, setCategory }) => {
  return (
    <div className="filters">
      <select value={month} onChange={(e) => setMonth(e.target.value)}>
        <option value="">All Months</option>
        {[
          "January", "February", "March", "April", "May", "June",
          "July", "August", "September", "October", "November", "December"
        ].map((m, i) => (
          <option key={i} value={i + 1}>{m}</option>
        ))}
      </select>

      <select value={category} onChange={(e) => setCategory(e.target.value)}>
        <option value="">All Categories</option>
        <option value="salary">Salary</option>
        <option value="food">Food</option>
        <option value="rent">Rent</option>
        <option value="entertainment">Entertainment</option>
        <option value="other">Other</option>
      </select>
    </div>
  );
};

export default Filters;

