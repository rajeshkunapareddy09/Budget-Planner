import React, { useEffect, useState } from "react";
import { auth, db } from "../firebase";
import { useAuthState } from "react-firebase-hooks/auth";
import {
  doc,
  setDoc,
  getDoc,
  collection,
  addDoc,
  onSnapshot,
  deleteDoc
} from "firebase/firestore";
import "../styles/SalaryDashboard.css";

const SalaryDashboard = () => {
  const [user] = useAuthState(auth);
  const [salary, setSalary] = useState("");
  const [fixedExpenses, setFixedExpenses] = useState([]);
  const [title, setTitle] = useState("");
  const [amount, setAmount] = useState("");

  useEffect(() => {
    if (!user) return;

    // Fetch salary
    getDoc(doc(db, "users", user.uid, "salary", "currentMonth")).then((docSnap) => {
      if (docSnap.exists()) {
        setSalary(docSnap.data().amount);
      }
    });

    // Fetch fixed expenses
    const unsub = onSnapshot(collection(db, "users", user.uid, "fixedExpenses"), (snapshot) => {
      const data = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
      setFixedExpenses(data);
    });

    return () => unsub();
  }, [user]);

  const handleSalarySubmit = async () => {
    if (!user || !salary) return;
    await setDoc(doc(db, "users", user.uid, "salary", "currentMonth"), {
      amount: Number(salary),
    });
  };

  const handleAddExpense = async () => {
    if (!user || !title || !amount) return;
    await addDoc(collection(db, "users", user.uid, "fixedExpenses"), {
      title,
      amount: Number(amount),
    });
    setTitle("");
    setAmount("");
  };

  const handleDeleteExpense = async (id) => {
    await deleteDoc(doc(db, "users", user.uid, "fixedExpenses", id));
  };

  const totalFixed = fixedExpenses.reduce((sum, item) => sum + item.amount, 0);
  const remaining = salary - totalFixed;

  return (
    <div className="salary-dashboard">
      <h2>💼 Salary Dashboard</h2>

      <div className="salary-input">
        <input
          type="number"
          placeholder="Enter Monthly Salary"
          value={salary}
          onChange={(e) => setSalary(e.target.value)}
        />
        <button onClick={handleSalarySubmit}>Save Salary</button>
      </div>

      <div className="expense-form">
        <input
          type="text"
          placeholder="Expense Title (e.g. Rent)"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        <input
          type="number"
          placeholder="Amount"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
        <button onClick={handleAddExpense}>Add Fixed Expense</button>
      </div>

      <div className="summary">
        <p><strong>Total Salary:</strong> ₹{salary}</p>
        <p><strong>Fixed Expenses:</strong> ₹{totalFixed}</p>
        <p><strong>Remaining Salary:</strong> ₹{remaining}</p>
      </div>

      <div className="expense-list">
        <h4>Fixed Expenses</h4>
        {fixedExpenses.length === 0 ? (
          <p>No fixed expenses added yet.</p>
        ) : (
          fixedExpenses.map((item) => (
            <div key={item.id} className="expense-item">
              ₹{item.amount} - {item.title}
              <button onClick={() => handleDeleteExpense(item.id)}>❌</button>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default SalaryDashboard;

