import React, { useEffect, useState } from "react";
import { Pie } from "react-chartjs-2";
import { collection, onSnapshot } from "firebase/firestore";
import { auth, db } from "../firebase";
import { useAuthState } from "react-firebase-hooks/auth";
import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend
} from "chart.js";

ChartJS.register(ArcElement, Tooltip, Legend);

const ChartView = () => {
  const [user] = useAuthState(auth);
  const [income, setIncome] = useState(0);
  const [expense, setExpense] = useState(0);

  useEffect(() => {
    if (!user) return;

    const unsubscribe = onSnapshot(
      collection(db, "users", user.uid, "transactions"),
      (snapshot) => {
        let totalIncome = 0;
        let totalExpense = 0;

        snapshot.docs.forEach((doc) => {
          const data = doc.data();
          if (data.type === "income") totalIncome += data.amount;
          if (data.type === "expense") totalExpense += data.amount;
        });

        setIncome(totalIncome);
        setExpense(totalExpense);
      }
    );

    return () => unsubscribe();
  }, [user]);

  const data = {
    labels: ["Income", "Expense"],
    datasets: [
      {
        label: "Budget Breakdown",
        data: [income, expense],
        backgroundColor: ["#2ecc71", "#e74c3c"],
        borderColor: ["#27ae60", "#c0392b"],
        borderWidth: 1,
      },
    ],
  };

  const options = {
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: "bottom",
        labels: {
          font: {
            size: 12,
          },
        },
      },
    },
  };

  return (
    <div style={{ width: 250, height: 250, margin: "20px auto" }}>
      <h3 style={{ textAlign: "center", fontSize: "1rem" }}>Income vs Expense</h3>
      <Pie data={data} options={options} width={200} height={200} />
    </div>
  );
};

export default ChartView;

