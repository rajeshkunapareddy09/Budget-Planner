// src/components/About.js
import React from "react";
import "../styles/About.css"; // Optional for custom styling

const About = () => {
  return (
    <div className="about-container">
      <h1>About Budget Planner 💸</h1>
      <p>
        Budget Planner is a simple and powerful web application designed to help you track
        your income and expenses with ease. Whether you're saving for a goal or just trying
        to manage day-to-day finances, our tool keeps everything organized.
      </p>

      <h3>Features</h3>
      <ul>
        <li>🔹 Add and track income/expenses</li>
        <li>🔹 Filter by category and month</li>
        <li>🔹 Visualize spending with Pie and Bar Charts</li>
        <li>🔹 Secure login using Firebase Authentication</li>
        <li>🔹 Real-time database with Cloud Firestore</li>
      </ul>

      <p>
        This application is built using <strong>React.js</strong>, <strong>Firebase</strong>, and <strong>Chart.js</strong> to provide
        a fast, secure, and responsive experience. Our goal is to empower users to take
        control of their personal finances in a fun and intuitive way.
      </p>
    </div>
  );
};

export default About;

