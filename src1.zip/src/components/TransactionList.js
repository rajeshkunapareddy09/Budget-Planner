import React, { useEffect, useState } from "react";
import { collection, onSnapshot, query, orderBy } from "firebase/firestore";
import { auth, db } from "../firebase";
import { useAuthState } from "react-firebase-hooks/auth";
import "../styles/TransactionList.css";

const TransactionList = () => {
  const [transactions, setTransactions] = useState([]);
  const [user] = useAuthState(auth);

  useEffect(() => {
    if (!user) return;

    const q = query(
      collection(db, "users", user.uid, "transactions"),
      orderBy("createdAt", "desc")
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setTransactions(data);
    });

    return () => unsubscribe();
  }, [user]);

  return (
    <div className="transaction-list-container">
      {transactions.length === 0 ? (
        <p className="no-transactions">No transactions found.</p>
      ) : (
        transactions.map((tx) => (
          <div
            className={`transaction-card ${tx.type === "income" ? "income" : "expense"}`}
            key={tx.id}
          >
            <div className="transaction-top">
              <strong>₹{tx.amount}</strong>
              <span className="type-label">{tx.type.toUpperCase()}</span>
            </div>
            <div className="transaction-meta">
              <span className="category">{tx.category}</span>
              {tx.note && <span className="note">📝 {tx.note}</span>}
              <span className="date">
                {tx.createdAt?.toDate().toLocaleString() || "Pending..."}
              </span>
            </div>
          </div>
        ))
      )}
    </div>
  );
};

export default TransactionList;

