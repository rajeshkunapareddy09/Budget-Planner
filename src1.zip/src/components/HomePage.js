import React from "react";

const HomePage = () => {
  const backgroundStyle = {
    backgroundImage: "url('/images/b4.jpeg')", // ✅ Make sure this matches file name
    backgroundSize: "cover",
    backgroundPosition: "center",
    minHeight: "100vh",
    color: "white",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    textAlign: "center",
    padding: "40px",
  };

  const overlayStyle = {
    backgroundColor: "rgba(0, 0, 0, 0.9)",
    paddingTop: "20px",
    borderRadius: "10px",
    maxWidth: "700px",
    width: "90%",
    height:"200px",
  };

  return (
    <div style={backgroundStyle}>
      <div style={overlayStyle}>
        <h1>💸 Budget Planner</h1>
        <p>Track your expenses and take control of your finances.</p>
      </div>
    </div>
  );
};

export default HomePage;

