import React, { useEffect, useState } from "react";
import { Bar } from "react-chartjs-2";
import { collection, onSnapshot } from "firebase/firestore";
import { auth, db } from "../firebase";
import { useAuthState } from "react-firebase-hooks/auth";
import {
  Chart as ChartJS,
  BarElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(BarElement, CategoryScale, LinearScale, Tooltip, Legend);

const BarChartView = () => {
  const [user] = useAuthState(auth);
  const [categoryData, setCategoryData] = useState({});

  useEffect(() => {
    if (!user) return;

    const unsubscribe = onSnapshot(
      collection(db, "users", user.uid, "transactions"),
      (snapshot) => {
        const categoryTotals = {};

        snapshot.docs.forEach((doc) => {
          const data = doc.data();
          if (data.category && data.type === "expense") {
            categoryTotals[data.category] =
              (categoryTotals[data.category] || 0) + data.amount;
          }
        });

        setCategoryData(categoryTotals);
      }
    );

    return () => unsubscribe();
  }, [user]);

  const data = {
    labels: Object.keys(categoryData),
    datasets: [
      {
        label: "Expenses by Category",
        data: Object.values(categoryData),
        backgroundColor: "#3498db",
        borderRadius: 5,
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: "bottom",
      },
    },
    scales: {
      y: {
        beginAtZero: true,
      },
    },
  };

  return (
    <div style={{ maxWidth: 500, margin: "30px auto" }}>
      <h3 style={{ textAlign: "center" }}>Expenses by Category</h3>
      <Bar data={data} options={options} />
    </div>
  );
};

export default BarChartView;

