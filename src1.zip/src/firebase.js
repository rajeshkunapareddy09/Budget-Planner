import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";

// Paste your config here
const firebaseConfig = {
 apiKey: "AIzaSyAX1oCYczNVzOI5QqYC7n4jtwrq23MCAQ4",
  authDomain: "budget-planner-99ae5.firebaseapp.com",
  projectId: "budget-planner-99ae5",
  storageBucket: "budget-planner-99ae5.firebasestorage.app",
  messagingSenderId: "883877048931",
  appId: "1:883877048931:web:53937b19a87b42f6a0fe56",
  measurementId: "G-8BP1TJKG61"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Export the Firestore and Auth services
export const db = getFirestore(app);
export const auth = getAuth(app);

